package com.example.flutterproject

import io.flutter.embedding.android.FlutterActivity
import android.os.Bundle

class MainActivity: FlutterActivity(){

    override fun onCreate(savedInstanceState: Bundle?) {
//        val splashScreen = SplashScreen.installSplashScreen(this)
        super.onCreate(savedInstanceState)
    }
}
