import 'package:flutter/material.dart';
import 'package:flutterproject/views/change_password_screen.dart';
import 'package:flutterproject/views/device_list_screen.dart';
import 'package:flutterproject/views/get_all_users_screen.dart';
import 'package:flutterproject/views/login_screen.dart';
import 'package:provider/provider.dart';
import '../core/models/main_model.dart';
import '../viewmodel/main_viewmodel.dart';
// import '../views/get_all_users_screen.dart';
// import '../views/add_user_screen.dart';
import '../views/delete_user_dialog.dart';

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  _MainScreenState createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  @override
  void initState() {
    super.initState();
    Future.microtask(() => Provider.of<MainViewModel>(context, listen: false)
        .fetchInverterData(context));
  }

  @override
  Widget build(BuildContext context) {
    final mainViewModel = Provider.of<MainViewModel>(context);

    return Scaffold(
      appBar: AppBar(
        title: Text("Inverter Data"),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (context) => LoginScreen()),
            );
          },
        ),
        actions: [
          PopupMenuButton<String>(
            onSelected: (value) {
              if (value == 'getAllUsers') {
                Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                        builder: (context) => GetAllUsersScreen()));
              } else if (value == 'deleteUser') {
                Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                        builder: (context) => DeleteUserDialog()));
              } else if (value == 'inverterDevices') {
                Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                        builder: (context) => DeviceListScreen()));
              }
            },
            itemBuilder: (context) => [
              PopupMenuItem(
                value: 'getAllUsers',
                child: Text("Get All Users"),
              ),
              PopupMenuItem(
                value: 'deleteUser',
                child: Text("Delete User"),
              ),
              PopupMenuItem(
                value: 'inverterDevices',
                child: Text("Inverter Devices"),
              ),
            ],
          ),
        ],
      ),
      body: mainViewModel.isLoading
          ? Center(child: CircularProgressIndicator())
          : mainViewModel.latestInverter == null
              ? Center(child: Text("No data available"))
              : _buildInverterCard(mainViewModel.latestInverter!),
    );
  }

  Widget _buildInverterCard(MainModel inverter) {
    return Align(
      alignment: Alignment.center,
      child: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: 350),
        child: Card(
          elevation: 4,
          margin: EdgeInsets.all(10),
          child: Padding(
            padding: EdgeInsets.all(12),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Icon(Icons.bolt, color: Colors.orange, size: 30),
                    Text(
                      inverter.createdAt.split("T")[0],
                      style: TextStyle(color: Colors.blueGrey),
                    ),
                  ],
                ),
                SizedBox(height: 8),
                Text(
                  "${inverter.deviceName} - ${inverter.version}",
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                ),
                Divider(),
                Wrap(
                  direction: Axis.vertical,
                  spacing: 4,
                  children: [
                    Text("ID: ${inverter.id}"),
                    Text("Energy Consumed: ${inverter.energyConsumed}J"),
                    Text("Generated Power: ${inverter.genPower}J"),
                    Text("PV Voltage: ${inverter.pvVoltage}V"),
                    Text("Output Voltage: ${inverter.outputVoltage}V"),
                    Text("Output Current: ${inverter.outputCurrent}A"),
                    Text("MAC Address: ${inverter.macAddress}"),
                    Text("Error: ${inverter.error}"),
                    Text("Device Name: ${inverter.deviceName}"),
                    Text("Version: ${inverter.version}"),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
