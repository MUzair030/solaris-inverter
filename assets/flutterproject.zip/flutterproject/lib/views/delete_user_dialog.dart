import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../viewmodel/delete_user_viewmodel.dart';
import '../viewmodel/user_viewmodel.dart';
import 'get_all_users_screen.dart'; // Import your GetAllUsersScreen

class DeleteUserDialog extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    TextEditingController idController = TextEditingController();

    return AlertDialog(
      title: Text("Delete User"),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text("Enter the ID of the user to delete:"),
          SizedBox(height: 10),
          TextField(
            controller: idController,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(
              border: OutlineInputBorder(),
              hintText: "Enter User ID",
            ),
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: Text("Cancel"),
        ),
        TextButton(
          onPressed: () async {
            String userIdText = idController.text.trim();
            int? userId = int.tryParse(userIdText);

            if (userId != null) {
              await Provider.of<DeleteUserViewModel>(context, listen: false)
                  .deleteUser(userId);

              print("Delete request sent!");

              // Refresh the user list after deletion
              Provider.of<UserViewModel>(context, listen: false).fetchUsers();

              // Navigate back to the GetAllUsersScreen
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => GetAllUsersScreen()),
              );
            } else {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text("Invalid ID! Enter a valid number.")),
              );
            }
          },
          child: Text("Delete", style: TextStyle(color: Colors.red)),
        ),
      ],
    );
  }
}
