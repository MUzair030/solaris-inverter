import 'package:flutter/material.dart';
import 'package:flutterproject/views/login_screen.dart';
import 'package:flutterproject/views/main_screen.dart';
import 'package:provider/provider.dart';
import '../viewmodel/user_viewmodel.dart';
import '../viewmodel/delete_user_viewmodel.dart';
import 'delete_user_dialog.dart';

class GetAllUsersScreen extends StatefulWidget {
  @override
  _GetAllUsersScreenState createState() => _GetAllUsersScreenState();
}

class _GetAllUsersScreenState extends State<GetAllUsersScreen> {
  @override
  void initState() {
    super.initState();
    Future.microtask(
        () => Provider.of<UserViewModel>(context, listen: false).fetchUsers());
  }

  @override
  Widget build(BuildContext context) {
    final userViewModel = Provider.of<UserViewModel>(context);
    // final deleteUserViewModel = Provider.of<DeleteUserViewModel>(context);

    return Scaffold(
      extendBodyBehindAppBar: true,
      body: Stack(
        children: [
          // Background Image
          Positioned.fill(
            child: Image.asset(
              "assets/dashboardbg.png",
              fit: BoxFit.cover,
            ),
          ),
          // Dark Overlay for readability
          Positioned.fill(
            child: Container(color: Colors.black.withOpacity(0.5)),
          ),
          Column(
            crossAxisAlignment:
                CrossAxisAlignment.start, // Align content to left
            children: [
              const SizedBox(height: 60),
              // Back Button, Logo, and "All Users" in Row
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    IconButton(
                      icon: const Icon(Icons.arrow_back, color: Colors.white),
                      onPressed: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(builder: (context) => MainScreen()),
                        );
                      },
                    ),
                    const SizedBox(width: 10),
                    Image.asset(
                      "assets/splashicon.png",
                      height: 40,
                    ),
                    const SizedBox(width: 20),
                    const Text(
                      "All Users",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 30),
              // Welcome Text Section
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 30),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: const [
                    Text(
                      "Welcome Home",
                      style: TextStyle(
                        color: Colors.green,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: 5),
                    Text(
                      "No matter how far you go, home will be your",
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 14,
                      ),
                    ),
                    Text(
                      "destination to return to. Let's make your home",
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 14,
                      ),
                    ),
                    Text(
                      "comfortable.",
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              // Users List
              Expanded(
                child: userViewModel.isLoading
                    ? const Center(child: CircularProgressIndicator())
                    : userViewModel.errorMessage != null
                        ? Center(
                            child: Text(
                              userViewModel.errorMessage!,
                              style: const TextStyle(color: Colors.white),
                            ),
                          )
                        : ListView.builder(
                            padding: const EdgeInsets.all(16),
                            itemCount: userViewModel.users.length,
                            itemBuilder: (context, index) {
                              final user = userViewModel.users[index];
                              return Card(
                                color: Colors.white.withOpacity(0.2),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: ListTile(
                                  leading: const Icon(Icons.person,
                                      color: Colors.white),
                                  title: Text(
                                    user.username,
                                    style: const TextStyle(color: Colors.white),
                                  ),
                                  subtitle: Text(
                                    user.email,
                                    style:
                                        const TextStyle(color: Colors.white70),
                                  ),
                                  trailing: IconButton(
                                    icon: const Icon(Icons.delete,
                                        color: Colors.grey),
                                    onPressed: () {
                                      showDialog(
                                        context: context,
                                        builder: (context) =>
                                            DeleteUserDialog(),
                                      );
                                    },
                                  ),
                                ),
                              );
                            },
                          ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
