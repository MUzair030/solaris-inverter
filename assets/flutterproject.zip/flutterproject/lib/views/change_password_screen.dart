import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../viewmodel/change_password_viewmodel.dart';

class ChangePasswordScreen extends StatelessWidget {
  final TextEditingController oldPasswordController = TextEditingController();
  final TextEditingController newPasswordController = TextEditingController();
  final TextEditingController confirmPasswordController =
      TextEditingController();

  ChangePasswordScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Change Password")),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: oldPasswordController,
              decoration: InputDecoration(labelText: "Old Password"),
              obscureText: true,
            ),
            TextField(
              controller: newPasswordController,
              decoration: InputDecoration(labelText: "New Password"),
              obscureText: true,
            ),
            TextField(
              controller: confirmPasswordController,
              decoration: InputDecoration(labelText: "Confirm Password"),
              obscureText: true,
            ),
            SizedBox(height: 20),
            Consumer<ChangePasswordViewModel>(
              builder: (context, viewModel, child) {
                return Column(
                  children: [
                    if (viewModel.errorMessage != null)
                      Text(viewModel.errorMessage!,
                          style: TextStyle(color: Colors.red)),
                    if (viewModel.successMessage != null)
                      Text(viewModel.successMessage!,
                          style: TextStyle(color: Colors.green)),
                    if (viewModel.isLoading)
                      CircularProgressIndicator()
                    else
                      ElevatedButton(
                        onPressed: () {
                          viewModel.changePassword(
                            oldPasswordController.text,
                            newPasswordController.text,
                            confirmPasswordController.text,
                            "Actual token", // Replace with actual token
                            // "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhZG1pbiIsImlhdCI6MTc0MTU5MTg1MiwiZXhwIjoxNzU3MzYxODUyfQ.xUmsegbi1Um7X_tw3kYv9m4SP9_Mcy6rJf48wzWQ87I"
                          );
                        },
                        child: Text("Change Password"),
                      ),
                  ],
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
