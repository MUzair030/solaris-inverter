import 'package:flutter/material.dart';
import 'package:flutterproject/views/change_password_screen.dart';
import 'package:flutterproject/views/signup_screen.dart';
import 'package:provider/provider.dart';
import '../viewmodel/signin_viewmodel.dart';

class LoginScreen extends StatelessWidget {
  final TextEditingController usernameController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final signinViewModel = Provider.of<SigninViewModel>(context);

    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (context) => SignupScreen()),
            );
          },
        ),
      ),
      body: Stack(
        children: [
          // Background Image
          Positioned.fill(
            child: Image.asset(
              "assets/splashbg.png", // Update with your image path
              fit: BoxFit.cover,
            ),
          ),
          Positioned.fill(
            child: Container(color: Colors.black.withOpacity(0.5)),
          ),
          // Content
          SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 32.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const SizedBox(height: 100), // Ensures spacing at the top
                  // Logo
                  SizedBox(
                    height: 80,
                    child: Image.asset("assets/splashicon.png",
                        fit: BoxFit.contain),
                  ),
                  const SizedBox(height: 30),

                  // Username Field
                  TextField(
                    controller: usernameController,
                    style: const TextStyle(color: Colors.white),
                    decoration: InputDecoration(
                      filled: true,
                      fillColor: Colors.white.withOpacity(0.2),
                      hintText: "Enter username or email",
                      hintStyle: TextStyle(color: Colors.white70),
                      prefixIcon: Icon(Icons.email, color: Colors.white70),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide.none,
                      ),
                    ),
                  ),
                  const SizedBox(height: 15),

                  // Password Field
                  TextField(
                    controller: passwordController,
                    obscureText: true,
                    style: const TextStyle(color: Colors.white),
                    decoration: InputDecoration(
                      filled: true,
                      fillColor: Colors.white.withOpacity(0.2),
                      hintText: "Enter password",
                      hintStyle: TextStyle(color: Colors.white70),
                      prefixIcon: Icon(Icons.lock, color: Colors.white70),
                      suffixIcon:
                          Icon(Icons.visibility_off, color: Colors.white70),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide.none,
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),

                  // Forgot Password
                  Align(
                    alignment: Alignment.centerRight,
                    child: TextButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => ChangePasswordScreen()),
                        );
                      },
                      child: const Text("Forgot password?",
                          style: TextStyle(color: Colors.white70)),
                    ),
                  ),
                  const SizedBox(height: 10),

                  // Login Button
                  signinViewModel.isLoading
                      ? const CircularProgressIndicator()
                      : SizedBox(
                          width: double.infinity,
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              padding: const EdgeInsets.symmetric(vertical: 14),
                              backgroundColor: Colors.grey[400],
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10),
                              ),
                            ),
                            onPressed: () {
                              signinViewModel.login(
                                username: usernameController.text,
                                password: passwordController.text,
                                context: context,
                              );
                            },
                            child: const Text("Log in",
                                style: TextStyle(color: Colors.black)),
                          ),
                        ),
                  const SizedBox(height: 20),

                  // OR Divider
                  const Text("OR", style: TextStyle(color: Colors.white70)),
                  const SizedBox(height: 20),

                  // Fingerprint Icon
                  Icon(Icons.fingerprint, color: Colors.white70, size: 50),
                  const SizedBox(height: 20),

                  // Create New Account
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton(
                      style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        side: const BorderSide(color: Colors.green),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                      onPressed: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                              builder: (context) => SignupScreen()),
                        );
                      },
                      child: const Text("Create new account",
                          style: TextStyle(color: Colors.green)),
                    ),
                  ),
                  const SizedBox(height: 20),

                  // Social Icons
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SizedBox(
                        height: 30,
                        child: Image.asset("assets/apple_logo.png",
                            fit: BoxFit.contain),
                      ),
                      const SizedBox(width: 20),
                      SizedBox(
                        height: 30,
                        child: Image.asset("assets/google_logo.png",
                            fit: BoxFit.contain),
                      ),
                    ],
                  ),
                  const SizedBox(height: 50), // Adds space at the bottom
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
