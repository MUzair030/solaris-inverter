import 'package:flutter/material.dart';
import 'package:flutterproject/views/add_device_screen.dart';
import 'package:flutterproject/views/main_screen.dart';
import 'package:provider/provider.dart';
import '../viewmodel/devices_viewmodel.dart';
import '../core/models/devices_list_model.dart';

class DeviceListScreen extends StatefulWidget {
  const DeviceListScreen({super.key});

  @override
  _DeviceListScreenState createState() => _DeviceListScreenState();
}

class _DeviceListScreenState extends State<DeviceListScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Provider.of<DevicesViewModel>(context, listen: false).fetchDevices();
    });
  }

  void _showAddDevicesScreen() async {
    bool? deviceAdded = await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => AddDeviceScreen()),
    );

    if (deviceAdded == true) {
      Provider.of<DevicesViewModel>(context, listen: false).fetchDevices();
    }
  }

  @override
  Widget build(BuildContext context) {
    final deviceViewModel = Provider.of<DevicesViewModel>(context);

    return Scaffold(
      extendBodyBehindAppBar: true,
      body: Stack(
        children: [
          // Background Image
          Positioned.fill(
            child: Image.asset(
              "assets/dashboardbg.png",
              fit: BoxFit.cover,
            ),
          ),
          // Dark Overlay
          Positioned.fill(
            child: Container(color: Colors.black.withOpacity(0.5)),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 60),
              // App Bar Section
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    IconButton(
                      icon: const Icon(Icons.arrow_back, color: Colors.white),
                      onPressed: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(builder: (context) => MainScreen()),
                        );
                      },
                    ),
                    const SizedBox(width: 10),
                    Image.asset(
                      "assets/splashicon.png",
                      height: 40,
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: const Text(
                        "Inverter Devices",
                        overflow: TextOverflow.ellipsis, // Avoids text overflow
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.add, color: Colors.white),
                      onPressed: _showAddDevicesScreen,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 30),
              // Welcome Text
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 30),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: const [
                    Text(
                      "Welcome Home",
                      style: TextStyle(
                        color: Colors.green,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: 5),
                    Text(
                      "No matter how far you go, home will be your",
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 14,
                      ),
                    ),
                    Text(
                      "destination to return to. Let's make your home",
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 14,
                      ),
                    ),
                    Text(
                      "comfortable.",
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              // Device List Section
              Expanded(
                child: deviceViewModel.isLoading
                    ? const Center(child: CircularProgressIndicator())
                    : deviceViewModel.errorMessage.isNotEmpty
                        ? Center(
                            child: Text(
                              deviceViewModel.errorMessage,
                              style: const TextStyle(color: Colors.white),
                            ),
                          )
                        : deviceViewModel.devices.isEmpty
                            ? const Center(
                                child: Text(
                                  "No devices found",
                                  style: TextStyle(color: Colors.white),
                                ),
                              )
                            : ListView.builder(
                                padding: const EdgeInsets.all(16),
                                itemCount: deviceViewModel.devices.length,
                                itemBuilder: (context, index) {
                                  DevicesListModel device = deviceViewModel
                                      .devices.reversed
                                      .toList()[index];

                                  return Card(
                                    color: Colors.white.withOpacity(0.2),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    child: ListTile(
                                      leading: const Icon(
                                          Icons.electrical_services,
                                          color: Colors.white),
                                      title: Text(
                                        "MAC: ${device.macAddress}",
                                        style: const TextStyle(
                                            color: Colors.white),
                                      ),
                                      subtitle: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            "Inverter: ${device.inverterName}",
                                            style: const TextStyle(
                                                color: Colors.white70),
                                          ),
                                          if (device.user != null) ...[
                                            Text(
                                              "Id: ${device.user.id}",
                                              style: const TextStyle(
                                                  color: Colors.white70),
                                            ),
                                            Text(
                                              "User: ${device.user.username}",
                                              style: const TextStyle(
                                                  color: Colors.white70),
                                            ),
                                            Text(
                                              "Email: ${device.user.email}",
                                              style: const TextStyle(
                                                  color: Colors.white70),
                                            ),
                                            Text(
                                              "Phone: ${device.user.phone}",
                                              style: const TextStyle(
                                                  color: Colors.white70),
                                            ),
                                            Text(
                                              "Address: ${device.user.address}",
                                              style: const TextStyle(
                                                  color: Colors.white70),
                                            ),
                                          ],
                                        ],
                                      ),
                                    ),
                                  );
                                },
                              ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
