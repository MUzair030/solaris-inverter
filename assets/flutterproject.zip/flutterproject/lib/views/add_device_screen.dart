import 'package:flutter/material.dart';
import 'package:flutterproject/views/device_list_screen.dart';
import 'package:provider/provider.dart';
import '../viewmodel/add_device_viewmodel.dart';

class AddDeviceScreen extends StatelessWidget {
  final TextEditingController macController = TextEditingController();
  final TextEditingController nameController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  AddDeviceScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => DeviceListScreen()),
          ),
        ),
      ),
      body: Stack(
        children: [
          // Background Image
          Positioned.fill(
            child: Image.asset("assets/splashbg.png", fit: BoxFit.cover),
          ),
          Positioned.fill(
            child: Container(color: Colors.black.withOpacity(0.5)),
          ),

          // Content
          SafeArea(
            child: Center(
              child: SingleChildScrollView(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 32.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      // Logo
                      SizedBox(
                        height: 80,
                        child: Image.asset("assets/splashicon.png",
                            fit: BoxFit.contain),
                      ),

                      const SizedBox(height: 40),

                      // Welcome Text
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: const [
                            Text(
                              "Welcome Home",
                              style: TextStyle(
                                color: Colors.green,
                                fontSize: 22,
                                fontWeight: FontWeight.bold,
                              ),
                              textAlign: TextAlign.center,
                            ),
                            SizedBox(height: 5),
                            Text(
                              "No matter how far you go, home will be your destination. Let's make your home comfortable.",
                              style: TextStyle(
                                  color: Colors.white70, fontSize: 14),
                              textAlign: TextAlign.center,
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 40),

                      // Form
                      Form(
                        key: _formKey,
                        child: Column(
                          children: [
                            // MAC Address Field
                            _buildTextField(macController, "Enter MAC Address"),
                            const SizedBox(height: 20),

                            // Device Name Field
                            _buildTextField(
                                nameController, "Enter Device Name"),
                            const SizedBox(height: 30),

                            // Submit Button
                            Consumer<AddDeviceViewModel>(
                              builder: (context, viewModel, child) {
                                return Column(
                                  children: [
                                    viewModel.isLoading
                                        ? const CircularProgressIndicator()
                                        : ElevatedButton(
                                            onPressed: () async {
                                              if (_formKey.currentState!
                                                  .validate()) {
                                                bool success =
                                                    await viewModel.addDevice(
                                                  macController.text.trim(),
                                                  nameController.text.trim(),
                                                );

                                                if (success) {
                                                  Navigator.pop(context,
                                                      true); // ✅ Refresh
                                                }
                                              }
                                            },
                                            style: ElevatedButton.styleFrom(
                                              padding:
                                                  const EdgeInsets.symmetric(
                                                      horizontal: 50,
                                                      vertical: 15),
                                            ),
                                            child: const Text("Add Device"),
                                          ),
                                    if (viewModel.message != null)
                                      Padding(
                                        padding: const EdgeInsets.only(top: 10),
                                        child: Text(
                                          viewModel.message!,
                                          style: TextStyle(
                                            color: viewModel.message ==
                                                    "Device added successfully!"
                                                ? Colors.green[300]
                                                : Colors.white,
                                          ),
                                        ),
                                      ),
                                  ],
                                );
                              },
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 50), // Adds space at the bottom
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // Helper Method for Input Fields
  Widget _buildTextField(TextEditingController controller, String hintText) {
    return TextFormField(
      controller: controller,
      style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(
        filled: true,
        fillColor: Colors.white.withOpacity(0.2),
        hintText: hintText,
        hintStyle: const TextStyle(color: Colors.white70),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide.none,
        ),
      ),
      validator: (value) => value!.isEmpty ? "$hintText is required" : null,
    );
  }
}
