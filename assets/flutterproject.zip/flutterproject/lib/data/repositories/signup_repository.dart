import '../../core/models/signup_model.dart';
import '../../core/network/signup_service.dart';
import '../../utils/shared_preferences_helper.dart';

class SignupRepository {
  final SignupService _signupService;

  SignupRepository(this._signupService);

  Future<String> signup(SignupModel user) async {
    String? token = await SharedPreferencesHelper.getToken();
    if (token == null) {
      return "Authentication error. Please log in again.";
    }
    return await _signupService.signup(user, token);
  }
}
