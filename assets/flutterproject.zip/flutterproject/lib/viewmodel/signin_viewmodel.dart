import 'package:flutter/material.dart';
import 'package:flutterproject/views/get_all_users_screen.dart';
import '../core/models/login_model.dart';
import '../data/usecases/signin_usecase.dart';
import '../utils/shared_preferences_helper.dart';

class SigninViewModel extends ChangeNotifier {
  final SigninUseCase _signinUseCase;
  bool isLoading = false;

  SigninViewModel(this._signinUseCase);

  Future<void> login({
    required String username,
    required String password,
    required BuildContext context,
  }) async {
    isLoading = true;
    notifyListeners();

    // ✅ Only allow admin to log in, block all other users
    if (username != "admin" || password != "123456789") {
      isLoading = false;
      notifyListeners();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Access denied! Only admin can log in."),
          backgroundColor: Colors.black,
        ),
      );
      return;
    }

    // ✅ Proceed with admin login
    LoginModel user = LoginModel(username: username, password: password);
    final loginResponse = await _signinUseCase.execute(user);

    isLoading = false;
    notifyListeners();

    if (loginResponse != null && loginResponse.token.isNotEmpty) {
      await SharedPreferencesHelper.saveToken(loginResponse.token);
      print("🟢 Admin logged in successfully: ${loginResponse.token}");

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => GetAllUsersScreen()),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Login failed. Please check your credentials."),
          backgroundColor: Colors.black,
        ),
      );
    }
  }
}
