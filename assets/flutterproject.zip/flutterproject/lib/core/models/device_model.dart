class DeviceModel {
  final String macAddress;
  final String inverterName;

  DeviceModel({required this.macAddress, required this.inverterName});
}
