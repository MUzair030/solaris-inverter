import 'package:dio/dio.dart';
import '../models/login_model.dart';
import '../models/login_response_model.dart';

class SigninService {
  final Dio _dio = Dio(BaseOptions(
    baseUrl: "http://db.3pol.com:24301/api/auth",
    connectTimeout: Duration(seconds: 10),
    receiveTimeout: Duration(seconds: 10),
    headers: {
      "Content-Type": "application/json",
    },
  ));

  Future<LoginResponseModel?> login(LoginModel user) async {
    try {
      Response response = await _dio.post("/signin", data: user.toJson());

      if (response.statusCode == 200) {
        return LoginResponseModel.fromJson(response.data);
      } else {
        print("❌ Server responded with status: ${response.statusCode}");
        return null;
      }
    } on DioException catch (e) {
      print("❌ Dio error: ${e.message}");
      return null;
    }
  }
}
